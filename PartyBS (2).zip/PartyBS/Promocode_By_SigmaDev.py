import sqlite3
import telebot
from database.DataBase import DataBase#окда
bot = telebot.TeleBot('7354474835:AAGLD6aLPM1cQG-rtIlsjfStSv6H6GgUlFU')

promocodes = {}
admins = ['1811487945']
#читаем
def load_promocodes():
    global promocodes
    try:
        with open('SigmaDev.txt', 'r') as file:
            lines = file.readlines()
            for line in lines:
                data = line.strip().split(':')
                promocode = data[0]
                amount = int(data[1])
                activations = int(data[2])
                promocodes[promocode] = {'amount': amount, 'activations': activations}
    except FileNotFoundError:
        print("ERROR Не найден тхт фаил! Будет ошибка")

load_promocodes()
#/start
@bot.message_handler(commands=['start'])
def send_welcome(message):
    bot.reply_to(message, "Привет! Я раб Dislikebrawl.Чтобы использовать промокод\n/use [айди] [промокод]")
#/use
@bot.message_handler(commands=['use'])
def use_promocode(message):
    args = message.text.split()
    if len(args) == 3:
        user_id = args[1]
        promocode = args[2]
        if promocode in promocodes and promocodes[promocode]['activations'] > 0:
            promocodes[promocode]['activations'] -= 1
            with open('SigmaDev.txt', 'w') as file:
                for key, value in promocodes.items():
                    file.write(f"{key}:{value['amount']}:{value['activations']}\n")
            bot.reply_to(message, f"Промокод '{promocode}' Был успешно активирован на айди '{user_id}' \nСумма гемов {promocodes[promocode]['amount']}")#верно
            add_gems(user_id, promocodes[promocode]['amount'])
        else:
            bot.reply_to(message, "Промокод не существует или уже был использован.")#кто успел тот и съел
    else:
        bot.reply_to(message, "Неверный формат команды. Используй /use [айди] [промокод].")#аглвоцорул т9 виноват

def add_gems(user_id, amount):
    # Добавление гемов в базу данных
    conn = sqlite3.connect("database/Player/plr.db")
    cursor = conn.cursor()
    cursor.execute("UPDATE plrs SET gems = gems + ? WHERE lowID = ?", (amount, user_id))
    conn.commit()
    conn.close()

# нормальный код кончился щяс будет говнокод
def use_promocode(message):
    args = message.text.split()
    if len(args) == 3:
        user_id = args[1]  # нахуто иаменяем user_id на low_id из базы данных
        promocode = args[2]
        if promocode in promocodes and promocodes[promocode]['activations'] > 0:
            promocodes[promocode]['activations'] -= 1
            bot.reply_to(message, f"Промокод {promocode} активирован для пользователя {user_id}. Сумма: {promocodes[promocode]['amount']}")#опять
            
            # Добавление гемов после удачного использования промокода
            add_gems(user_id, promocodes[promocode]['amount'])  #ещерос бля заменяем user_id на low_id
            
        else:
            bot.reply_to(message, "Промокод не существует или уже был использован.")
    else:
        bot.reply_to(message, "Неверный формат команды. Используй /use [айди] [промокод].")
#гдето я это видел...
#для разраба
@bot.message_handler(commands=['add_promocode'])
def add_promocode(message):
    if str(message.from_user.id) in admins:#если ты админ
        args = message.text.split()
        if len(args) == 4:
            promocode = args[1]
            amount = int(args[2])
            activations = int(args[3])
            promocodes[promocode] = {'amount': amount, 'activations': activations}
            with open('SigmaDev.txt', 'w') as file:
                for key, value in promocodes.items():
                    file.write(f"{key}:{value['amount']}:{value['activations']}\n")
            bot.reply_to(message, "Промокод успешно добавлен.")#вот молодец
        else:
            bot.reply_to(message, "Неверный формат команды. Используйте /add_promocode [промокод] [сумма] [активации].")#нет

print("Бот запущен")#то чего нет в других ботов!)
bot.polling()
#чтобы не оффнулся
