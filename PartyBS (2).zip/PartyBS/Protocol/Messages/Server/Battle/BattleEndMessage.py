from ByteStream.Writer import Writer


class BattleEndMessage(Writer):

    def __init__(self, client, player, type, result, players):
        super().__init__(client)
        self.id = 23456
        self.player  = player
        self.type    = type
        self.result  = result
        self.players = players

    def encode(self):
        self.writeInt(0)
        self.writeInt(1)
        self.writeInt(0)
        self.writeInt(1)
        self.writeVint(1) # Battle End Game Mode
        self.writeVint(3) # Result (Victory/Defeat/Draw/Rank Score)
        self.writeVint(0) # Tokens Gained
        self.writeVint(0) # Trophies Result
        self.writeVint(0) # Power Play Points Gained
        self.writeVint(0) # Doubled Tokens
        self.writeVint(0) # Double Token Event
        self.writeVint(0) # Token Doubler Remaining
        self.writeVint(0) # Special Events Level Passed
        self.writeVint(0) # Epic Win Power Play Points Gained
        self.writeVint(0) # Championship Level Reached
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(0)
        self.writeByte(16)
        self.writeVint(-1)
        self.writeBoolean(False)

        self.writeVint(1)  # Players

        for dudka in range(1):
            self.writeByte(1)
            self.writeDataReference(16, 0)  # BrawlerID
            self.writeDataReference(29, 0)  # SkinID
            self.writeVint(0) # Trophies
            self.writeVint(0)
            self.writeVint(10) # PowerLevel
            self.writeVint(0)
            self.writeBoolean(True)
            self.writeInt(0)
            self.writeInt(1)
            self.writeString("F1ash")  # PlayerName
            self.writeVint(100)
            self.writeVint(28000000)  # PlayerThumbnail
            self.writeVint(43000000)  # NameColor
            self.writeVint(46000000)

        self.writeVint(0)

        self.writeVint(0)  # XpEntry

        self.writeVint(0)

        self.writeVint(2)  # LogicMilestoneProgress
        self.writeVint(1)
        self.writeVint(0)
        self.writeVint(0)
        self.writeVint(5)
        self.writeVint(9999999)
        self.writeVint(9999999)

        self.writeDataReference(28, 0)

        self.writeBoolean(False)  # PlayAgainStatus

        self.writeBoolean(False)  # LogicQuests

        self.writeVint(0)
        self.writeVint(0)
        self.writeBoolean(False)  # LogicRankedMatchRoundState
        self.writeVint(-1)
        self.writeBoolean(False)  # ChronosTextEntry
