from ByteStream.Writer import Writer


class BattleResult2Message(Writer):

    def __init__(self, client, player, db):
        super().__init__(client)
        self.id = 23456
        self.player = player
        self.db = db

    def encode(self):
        brawler_trophies = self.player.brawlers_trophies[str(self.player.home_brawler)]
        brawler_trophies_for_rank = self.player.brawlers_high_trophies[str(self.player.home_brawler)]
        
        if 0 <= brawler_trophies <= 49:
        	win = 8
        	lose = 0
        	draw = 0
        	lose2 = 0


        else:
            if 50 <= brawler_trophies <= 99:
                win = 8
                lose = -1
                draw = 0
                lose2 = -64


            if 100 <= brawler_trophies <= 199:
                win = 8
                lose = -2
                draw = 0
                lose2 = -63


            if 200 <= brawler_trophies <= 299:
                win = 8
                lose = -3
                draw = 0
                lose2 = -62

            	
            if 300 <= brawler_trophies <= 399:
                win = 8
                lose = -4
                draw = 0
                lose2 = -61


            if 400 <= brawler_trophies <= 499:
                win = 8
                lose = -5
                draw = 0
                lose2 = -60

                
            if 500 <= brawler_trophies <= 549:
                win = 8
                lose = -5
                draw = 0
                lose2 = -60
                
            if 550 <= brawler_trophies <= 599:
                win = 8
                lose = -6
                draw = 0
                lose2 = -60

            if 600 <= brawler_trophies <= 649:
                win = 8
                lose = -6
                draw = 0
                lose2 = -59

            if 650 <= brawler_trophies <= 699:
                win = 8
                lose = -6
                draw = 0
                lose2 = -59

                
            if 700 <= brawler_trophies <= 749:
                win = 8
                lose = -7
                draw = 0
                lose2 = -58

            if 750 <= brawler_trophies <= 799:
                win = 8
                lose = -7
                draw = 0
                lose2 = -58

                
            if 800 <= brawler_trophies <= 849:
                win = 6
                lose = -8
                draw = 0
                lose2 = -57

                
            if 850 <= brawler_trophies <= 899:
                win = 6
                lose = -10
                draw = 0
                lose2 = -55

                
            if brawler_trophies >= 900:
                win = 3
                lose = -12
                draw = 0
                lose2 = -53
                
                
            		

        
        if self.player.battle_result == 0:
            trop = win
            self.player.trophies += win
            self.player.brawlers_high_trophies[str(self.player.home_brawler)] = brawler_trophies + win
            self.player.brawlers_trophies[str(self.player.home_brawler)] = brawler_trophies + win
            
            self.db.update_player_account(self.player.token, 'BrawlersTrophies', self.player.brawlers_trophies)
            self.db.update_player_account(self.player.token, 'BrawlersHighestTrophies', self.player.brawlers_high_trophies)

            self.db.update_player_account(self.player.token, 'Trophies', self.player.trophies)
            
            self.db.update_player_account(self.player.token, 'HighestTrophies', self.player.trophies)

        
        elif self.player.battle_result == 1:
            trop = lose
            self.player.trophies += lose
            self.player.brawlers_high_trophies[str(self.player.home_brawler)] = brawler_trophies + lose
            self.player.brawlers_trophies[str(self.player.home_brawler)] = brawler_trophies + lose
            
            self.db.update_player_account(self.player.token, 'BrawlersTrophies', self.player.brawlers_trophies)
            self.db.update_player_account(self.player.token, 'BrawlersHighestTrophies', self.player.brawlers_high_trophies)

            self.db.update_player_account(self.player.token, 'Trophies', self.player.trophies)
            
            self.db.update_player_account(self.player.token, 'HighestTrophies', self.player.trophies)
            
        self.writeVInt(1)
        self.writeVInt(self.player.battle_result)
        self.writeVInt(0)
        self.writeVInt(trop)#trp

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)

        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)
        self.writeVInt(0)# coin event

        self.writeVInt(0)# trp2
        self.writeVInt(16)
        self.writeVInt(-64)
        self.writeVInt(1)

        self.writeVInt(6) #players count
        
        self.writeVInt(1) # Team and Star Player Type
        self.writeDataReference(16, self.player.home_brawler) # Player Brawler
        self.writeDataReference(29, self.player.selected_skins[str(self.player.home_brawler)]) # Player Skin
        self.writeVInt(self.player.brawlers_trophies[str(self.player.home_brawler)]) # Your Brawler Trophies
        self.writeVInt(0) # Your Power Play Points
        self.writeVInt(10) # Your Brawler Power Level
        self.writeBoolean(True) # HighID and LowID Array
        self.writeInt(0) # HighID
        self.writeInt(self.player.ID) # LowID
        self.writeString(self.player.name) # Your Name
        self.writeVInt(1) # Player Experience Level
        self.writeVInt(28000000 + 0) # Player Profile Icon
        self.writeVInt(43000000 + self.player.name_color) # Player Name Color
        if self.player.bp_activated == True:
        	self.writeVInt(42000000 + self.player.name_color) # Gradient Name (42)
        else:
        		self.writeVInt(0) # Gradient Name (42)
        		
        self.writeVInt(0)# Team and Star Player Type
        self.writeVInt(16)
        self.writeVInt(self.player.bot1)# Player Brawler
        
        self.writeVInt(0)
        self.writeVInt(0)# Player Skin
        
        self.writeVInt(0)# Your Brawler Trophies
        self.writeVInt(10)# Your Brawler Power Level
        self.writeVInt(0)# HighID and LowID Array
        self.writeString(self.player.bot1_n)# Your Name
        self.writeVInt(100)# Player Experience Level
        self.writeVInt(28000000)# Player Profile Icon
        self.writeVInt(43000000)# Player Name Color
        self.writeVInt(0)# Player Name Gradient
        		
        		
        		
        self.writeVInt(0)# Team and Star Player Type
        self.writeVInt(16)
        self.writeVInt(self.player.bot2)# Player Brawler
        
        self.writeVInt(0)
        self.writeVInt(0)# Player Skin
        
        self.writeVInt(0)# Your Brawler Trophies
        self.writeVInt(10)# Your Brawler Power Level
        self.writeVInt(0)# HighID and LowID Array
        self.writeString(self.player.bot2_n)# Your Name
        self.writeVInt(100)# Player Experience Level
        self.writeVInt(28000000)# Player Profile Icon
        self.writeVInt(43000000)# Player Name Color
        self.writeVInt(0)# Player Name Gradient
        		
        
        		
        				
        						
        								
        										
        self.writeVInt(2)# Team and Star Player Type
        self.writeVInt(16)
        self.writeVInt(self.player.bot3)# Player Brawler
        
        self.writeVInt(0)
        self.writeVInt(0)# Player Skin
        
        self.writeVInt(0)# Your Brawler Trophies
        self.writeVInt(10)# Your Brawler Power Level
        self.writeVInt(0)# HighID and LowID Array
        self.writeString(self.player.bot3_n)# Your Name
        self.writeVInt(100)# Player Experience Level
        self.writeVInt(28000000)# Player Profile Icon
        self.writeVInt(43000000)# Player Name Color
        self.writeVInt(0)# Player Name Gradient
        
        
        
        		
        self.writeVInt(2)# Team and Star Player Type
        self.writeVInt(16)
        self.writeVInt(self.player.bot4)# Player Brawler
        
        self.writeVInt(0)
        self.writeVInt(0)# Player Skin
        
        self.writeVInt(0)# Your Brawler Trophies
        self.writeVInt(10)# Your Brawler Power Level
        self.writeVInt(0)# HighID and LowID Array
        self.writeString(self.player.bot4_n)# Your Name
        self.writeVInt(100)# Player Experience Level
        self.writeVInt(28000000)# Player Profile Icon
        self.writeVInt(43000000)# Player Name Color
        self.writeVInt(0)# Player Name Gradient
        	
        	
        self.writeVInt(2)# Team and Star Player Type
        self.writeVInt(16)
        self.writeVInt(self.player.bot5)# Player Brawler
        
        self.writeVInt(0)
        self.writeVInt(0)# Player Skin
        
        self.writeVInt(0)# Your Brawler Trophies
        self.writeVInt(10)# Your Brawler Power Level
        self.writeVInt(0)# HighID and LowID Array
        self.writeString(self.player.bot5_n)# Your Name
        self.writeVInt(100)# Player Experience Level
        self.writeVInt(28000000)# Player Profile Icon
        self.writeVInt(43000000)# Player Name Color
        if 1 == 1:
        	self.writeVInt(42000000 + 0) # Gradient Name (42)
        else:
        		self.writeVInt(0) # Gradient Name (42)
        		
        		
        		brawler_trophies = self.player.brawlers_trophies[str(self.player.home_brawler)]
        brawler_high = self.player.brawlers_high_trophies[str(self.player.home_brawler)]
        # Experience Array
        self.writeVInt(2) # Count
        self.writeVInt(0) # Normal Experience ID
        self.writeVInt(0) # Normal Experience Gained
        
        self.writeVInt(8) # Star Player Experience ID
        self.writeVInt(1) # Star Player Experience Gained

        # Rank Up and Level Up Bonus Array
        self.writeVInt(0) # Count

        # Trophies and Experience Bars Array
        self.writeVInt(2) # Count
        self.writeVInt(1) # Trophies Bar Milestone ID
        self.writeVInt(brawler_trophies - trop) # Brawler Trophies
        self.writeVInt(brawler_trophies_for_rank - trop) # Brawler Trophies for Rank
        
        self.writeVInt(5) # Experience Bar Milestone ID
        self.writeVInt(self.player.exp_points) # Player Experience
        self.writeVInt(self.player.exp_points) # Player Experience for Level

        self.writeDataReference(28, 0)

        self.writeBool(False)